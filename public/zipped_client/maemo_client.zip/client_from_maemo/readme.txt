Installing visualReST client

Step 1. (if you already have ruby, you can skip this step)
First you need to install ruby, libruby and libxml. Those can be found here:

http://code.scottishclimbs.com/maemo/repository/dists/chinook/free/binary-armel/ruby1.8-maemo_0.4.0_maemo4_armel.deb
http://code.scottishclimbs.com/maemo/repository/dists/chinook/free/binary-armel/libruby1.8_1.8.6-p110-1_maemo4_armel.deb
http://code.scottishclimbs.com/maemo/repository/dists/chinook/free/binary-armel/ruby1.8-libxml_0.5.1.0-1_armel.deb



Step 2.
Next thing is to install gems that client needs. Gems can be installed by: gem install <name>

List of gems needed:
gd2
grit
progressbar
trollop
xmpp4r
mime-types



Step 3.
Finally you need to install git for maemo. Git for maemo is still beta, but it seems to work ok.

One way to install the git:

1. Add repositories neede to install git to repository list: /etc/apt/sources.list.d/hildon-application-manager.list

Repositories needed:
deb http://repository.maemo.org/extras diablo free non-free
deb http://repository.maemo.org/extras-devel diablo free non-free

2. Then update and install git-core:
> apt-get update
> apt-get install git-core
3. Finally you can delete repositories you just added.


Step 4.
All the stuff should now be installed, which is needed to run visualReST client on maemo.
You can now use the client by:
> ruby client6.rb -h https://nota.cs.tut.fi:8443 -a 15
